int imageProcessing(int argc, const char* argv[]);
void summation();

int main(int argc, const char* argv[]) {
	imageProcessing(argc, argv);
	summation();
}